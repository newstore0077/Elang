package ahmyth.mine.king.ahmyth;

import android.app.admin.DeviceAdminReceiver;

public class AdminReceiver extends DeviceAdminReceiver {

}
